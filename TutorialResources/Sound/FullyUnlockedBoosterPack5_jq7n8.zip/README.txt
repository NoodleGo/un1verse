+--------------------------------------------------+
| The Binding of Isaac: Afterbirth+ Booster Pack 5 |
|             Fully Unlocked Save File             |
|                    by Zamiel                     |
+--------------------------------------------------+

Notes:

- This is a fully unlocked save file for The Binding of Isaac: Afterbirth+ Booster Pack #5.
- It also has 999 coins in the Donation Machine, and 999 coins in the Greed Donation Machine.
- It also has 10,000,000 Eden Tokens.
- You can put the save file into any slot you want, and you can even put it in all 3 slots if you so desire.
- You do NOT need to have 3 fully unlocked save files; the only thing that changes is that you get a custom graphic that says "3,000,000%!!!"



How to install (on Windows):

1) Make sure that the game is closed.

2) Open the "C:\Users\[YourUsername]\Documents\My Games\Binding of Isaac Afterbirth+\options.ini" file in Notepad. (If you have a custom "Documents" directory or installed Isaac to a custom location, the file may not be here, so you'll have to search around on your computer until you find it.)

3) Ctrl+F for the "SteamCloud" line to see whether it is equal to 1 or 0. (It is equal to 1 by default.)

4a) If "SteamCloud" is set to 1, then rename the "persistentgamedata.dat" file found in this zip file to either "abp_persistentgamedata1.dat", "abp_persistentgamedata2.dat", or "abp_persistentgamedata3.dat", depending on what slot you want it in.

4b) If "SteamCloud" is set to 0, then rename the "persistentgamedata.dat" file found in this zip file to either "persistentgamedata1.dat", "persistentgamedata2.dat", or "persistentgamedata3.dat", depending on what slot you want it in.

5a) If "SteamCloud" is set to 1, put the renamed file in the "C:\Program Files (x86)\Steam\userdata\[Steam ID]\250900\remote" directory.
(The "[Steam ID]" above refers to your Steam ID number. If you don't know it, just look inside the parent "userdata" directory, as there will probably only be one subdirectory there.)

5b) If "SteamCloud" is set to 0, put the renamed file in the "C:\Users\[YourUsername]\Documents\My Games\Binding of Isaac Afterbirth+\" directory.

6) Open the game, and you should have a fully unlocked file.



For more detailed information on how the Isaac folder structure works, read my guide here:
https://pastebin.com/kJFkFKz1



How to install (on MacOS / Linux):

1) Read the installation instructions for Windows above + read the above Pastebin so that you can get a feel for how things work on Windows.

2) Read this blog by Simon from Nicalis:
https://steamcommunity.com/app/250900/discussions/0/613941122558099449/
